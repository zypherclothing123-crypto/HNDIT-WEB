import { CpuSchedulingLab } from "@/components/labs/CpuSchedulingLab";
import { BattleArenaNotificationPing } from "@/components/notifications/BattleArenaNotificationPing";

export default function CpuSchedulingPage() {
  return (
    <div className="mx-auto max-w-7xl space-y-4">
      <BattleArenaNotificationPing />
      <div>
        <h1 className="text-2xl font-bold text-heading">CPU Scheduling Lab</h1>
        <p className="text-sm text-muted-foreground">
          Three-panel layout: theory, GSAP Gantt animation, mastery progress.
        </p>
      </div>
      <CpuSchedulingLab />
    </div>
  );
}
