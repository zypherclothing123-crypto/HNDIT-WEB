import { createClient } from "@/lib/supabase/server";
import { buildSubjectStats } from "@/lib/subject-stats";
import { AdminDashboardShell } from "@/components/admin/AdminDashboardShell";
import type { UploadRow } from "@/components/admin/RecentUploadsTable";
import { fetchWeeklyEngagement } from "@/lib/engagement-stats";

export default async function AdminDashboardPage() {
  const supabase = await createClient();

  const { count: studentCount } = await supabase
    .from("profiles")
    .select("*", { count: "exact", head: true });

  const { count: subjectCount } = await supabase
    .from("subjects")
    .select("*", { count: "exact", head: true });

  const { count: aiCount } = await supabase
    .from("uploaded_notes")
    .select("*", { count: "exact", head: true })
    .eq("ai_analyzed", true);

  const { count: quizCount } = await supabase
    .from("user_progress")
    .select("*", { count: "exact", head: true })
    .eq("completed", true);

  const { data: subjects } = await supabase
    .from("subjects")
    .select("id, name, year, semester, code")
    .order("year")
    .order("semester");

  const subjectStats = await buildSubjectStats(supabase, subjects ?? [], {
    limit: 8,
  });

  const { data: rawNotes } = await supabase
    .from("uploaded_notes")
    .select("id, file_name, file_url, ai_analyzed, created_at, subject_id")
    .order("created_at", { ascending: false })
    .limit(12);

  const subjectRows = await supabase
    .from("subjects")
    .select("id, name");
  const nameById = new Map(
    (subjectRows.data ?? []).map((s) => [s.id, s.name] as const)
  );

  const uploads: UploadRow[] =
    rawNotes?.map((n) => ({
      id: n.id,
      file_name: n.file_name,
      file_url: n.file_url,
      subject_id: n.subject_id,
      ai_analyzed: n.ai_analyzed,
      created_at: n.created_at,
      subject: n.subject_id
        ? { name: nameById.get(n.subject_id) ?? "—" }
        : null,
    })) ?? [];

  const engagement = await fetchWeeklyEngagement(supabase);

  return (
    <AdminDashboardShell
      stats={{
        totalStudents: studentCount ?? 0,
        activeSubjects: subjectCount ?? 0,
        aiAnalyses: aiCount ?? 0,
        quizCompletions: quizCount ?? 0,
      }}
      subjects={subjects ?? []}
      subjectStats={subjectStats}
      uploads={uploads}
      engagement={engagement}
    />
  );
}
